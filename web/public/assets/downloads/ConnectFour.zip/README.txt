# Connect Four Game
This is a text-based local Connect Four game for Windows.

## How to Play
1. Download `ConnectFour.exe` from this folder.
2. Double-click `ConnectFour.exe` to start the game.
3. Follow the on-screen prompts to play locally (two players required).

## Windows Defender/Antivirus Warning
If you see a warning from Windows Defender or your antivirus when running `ConnectFour.exe`, this is because the file is custom-built and not widely recognized. The game is safe to run if you downloaded it from my website.
To run the game:
- Click "More info" and then "Run anyway" if prompted by Windows SmartScreen.
- You may need to allow the file through your antivirus software.
